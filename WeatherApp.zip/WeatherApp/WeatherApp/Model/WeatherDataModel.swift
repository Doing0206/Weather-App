//
//  WeatherDataModel.swift
//  WeatherApp
//
//  Created by Doing on 2019/1/23.
//  Copyright © 2019 Doing. All rights reserved.
//

import Foundation

class WeatherDataModel{
    
    var temperature : Int = 0
    var condition :Int = 0
    var city :String = ""
    var weatherIconName : String = ""
    
    func updateWeatherIcon(conditionId: Int) -> String{
        
        switch conditionId {
        case 0...232:
            return "thunderstorm"
            
        case 300...531:
            return "rain"
            
        case 600...622:
            return "snow"
            
        case 701...781:
            return "mist"
            
        case 800:
            return "sunny"
            
        case 801...804:
            return "clouds"
            
        default:
            return "thunderstorm"
        }
    }
}
