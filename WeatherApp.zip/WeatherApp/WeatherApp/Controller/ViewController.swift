//
//  ViewController.swift
//  WeatherApp
//
//  Created by Doing on 2019/1/22.
//  Copyright © 2019 Doing. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SVProgressHUD

class ViewController: UIViewController,delegateProtocol {
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return .lightContent
    }
    
    //繼承頁面2的delegateProtocol，所以必須實作newCityName方法，透過此方法將頁面2所輸入的城市傳至頁面1
    func newCityName(city: String){
        //print(city)
        let keys : [String :String] = ["q":city,"appid":apiKey]
        
        SVProgressHUD.showInfo(withStatus: "載入中")//載入中圖示
        getWeatherData(url: openWeatherMapLinkage, keys: keys)
    }
    
    @IBOutlet weak var temperatureLable: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
    
    let openWeatherMapLinkage = "http://api.openweathermap.org/data/2.5/weather"
    let apiKey = "6230b5038e8b32eac3e5291a7fce0021"
    //http://api.openweathermap.org/data/2.5/weather?lat=24.977306&lon=121.545774&appid=6230b5038e8b32eac3e5291a7fce0021 完整網址
    let weatherDataModel = WeatherDataModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //經緯度
        let latitude = String(24.977306)
        let longtitude = String(121.545774)
        let input : [String:String] = ["lat":latitude,"lon":longtitude,"appid":apiKey] //存入經緯度＆金鑰 使網址讀取為
        
        SVProgressHUD.showInfo(withStatus: "載入中")//載入中圖示
        
        getWeatherData(url: openWeatherMapLinkage, keys: input)//呼叫getWeatherData方法，載入網址＆金鑰
    }
    
    func getWeatherData(url: String, keys: [String:String]){
        Alamofire.request(url, method: HTTPMethod.get , parameters: keys, encoding: URLEncoding.default, headers: nil).responseJSON { (response) in
            //成功串接
            if response.result.isSuccess{
                //print("Got data from server.")
                
                let weatherJSONData : JSON = JSON(response.result.value) //存入所有JSON資料
                
                //print(weatherJSONData)
                
                self.updateWeatherDate(json: weatherJSONData) //呼叫updateWeatherDate方法，拿需要的單筆資料
            }else{
                print("Cloud not got date. Error \(String(describing: response.result.error))")
            }
        }
    }
    
    //需要的資料解析 並存入
    func updateWeatherDate(json : JSON){
        if let temperature = json["main"]["temp"].double{
            weatherDataModel.temperature = Int(temperature - 273.15)
            weatherDataModel.city = json["name"].stringValue
            weatherDataModel.condition = json["weather"][0]["id"].intValue
            
            weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(conditionId: weatherDataModel.condition)
            
            updateUI()
            
        }else{
            cityLabel.text = "無法載入資料"
        }
    }
    
    //資料更新
    func updateUI(){
        temperatureLable.text = String(weatherDataModel.temperature) + "ºC"
        weatherIcon.image = UIImage(named: weatherDataModel.weatherIconName)
        cityLabel.text = weatherDataModel.city
        
        SVProgressHUD.dismiss() //加載圖示消失
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "gotoSecondView"{
            let destination = segue.destination as! SecondViewController
            destination.delegate = self
        }
    }

}

