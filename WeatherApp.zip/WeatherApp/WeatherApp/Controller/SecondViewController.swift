//
//  SecondViewController.swift
//  WeatherApp
//
//  Created by Doing on 2019/1/26.
//  Copyright © 2019 Doing. All rights reserved.
//

import UIKit

protocol delegateProtocol {
    func newCityName(city:String)
}

class SecondViewController: UIViewController {
    var delegate :delegateProtocol?
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return .lightContent
    }
    @IBAction func backToView1(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
 
    @IBOutlet weak var cityTextField: UILabel!
    
    //輸入城市名稱,透過delegate裡的newCityName方法，將值傳入頁面1
    @IBAction func getCityDetail(_ sender: UIButton) {
        
        if cityTextField.text != ""{
            
            let input = cityTextField.text
            delegate?.newCityName(city: input!)
            
            self.dismiss(animated: true, completion: nil)
        }
    }
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
